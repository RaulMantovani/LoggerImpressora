import hashlib

sha = hashlib.sha256()

CAMINHO_ZIP = r"C:\Log Impressora\Atualização\update.zip"
CAMINHO_HASH = r"C:\Log Impressora\Atualização\hash.txt"

with open(CAMINHO_ZIP, "rb") as f:
    for bloco in iter(lambda: f.read(4096), b""):
        sha.update(bloco)

with open(CAMINHO_HASH, "w") as f:
    f.write(sha.hexdigest())

print("Hash gerado:", sha.hexdigest())
from waitress import serve
import os
from flask import request, Flask, send_file,jsonify
from threading import Lock
from openpyxl import load_workbook
from datetime import datetime

app = Flask(__name__)
lock = Lock()  # Garante que só um processo escreva por vez

@app.route('/log_erro', methods=['POST'])
def log_erro():
    planilha = r'C:\Log Impressora\Planilhas\Logs de Erros.xlsx'
    workbook = load_workbook(planilha)
    planilha_aba = workbook['Erros']
    dados = request.get_json
    novo_log = [dados['hostname'], dados['ip'], dados['data_hora'], dados['mensagem']]
    planilha_aba.append(novo_log)
    workbook.save(planilha)


@app.route('/checar_versao', methods=['GET'])
def checar_versao():
    CAMINHO_VERSAO = r"C:\Log Impressora\versao.txt"
    with open(CAMINHO_VERSAO) as f:
        versao = f.read()
        
    return versao


@app.route('/hash', methods=['GET'])
def get_hash():
    CAMINHO_HASH = r"C:\Log Impressora\Atualização\hash.txt"
    if not os.path.exists(CAMINHO_HASH):
        return "Arquivo hash.txt não encontrado", 404
    
    with open(CAMINHO_HASH, "r") as f:
        hash = f.read().strip()

    return hash, 200

@app.route('/zip_nova_versao', methods=['GET'])
def enviar_zip():
   CAMINHO_ZIP = r"C:\Log Impressora\Atualização\update.zip"
   if not os.path.exists(CAMINHO_ZIP):
       return "Update.zip não encontrado", 404
   
   return send_file(CAMINHO_ZIP, as_attachment=True) 


@app.route('/atualizar_planilha', methods=['POST'])
def atualizar_planilha():
    dados = request.get_json()
    #impressoras = dados.get('impressoras', [])
    #cont_por_imp = dados.get('cont_por_imp', [])

    if not dados:
        return "Dados ausente", 400
    
    if not dados['hostname']:
        return "Hostname ausente", 400
    
    if not dados['ip']:
        return "IP ausente", 400
    
    if not dados['log']:
        return "Log ausente", 400

    caminho_planilha = r'C:\Log Impressora\Planilhas\Logs de Impressão 2025.xlsx'

    dia = int(datetime.now().strftime("%d"))
    mes = int(datetime.now().strftime("%m"))

    listaMeses = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio",
    "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"]

    with lock:  
        workbook = load_workbook(caminho_planilha)
        planilha_inventario = workbook['Inventario']
        usuario = "DADOS AUSENTES"
        setor = "DADOS AUSENTES"

        for fileira in planilha_inventario.iter_rows(min_row = 2, min_col = 1, max_col = 3):
            nome_pc = fileira[2].value
            nome_colaborador = fileira[0].value

            if nome_pc == dados['hostname']:
                usuario = nome_colaborador
                setor = fileira[1].value

        if (dia <= 20):
            if (mes == 12):
                planilha_logs = workbook[listaMeses[0]]
            else:
                planilha_logs = workbook[listaMeses[mes - 1]]
                
        elif(dia>20):
           planilha_logs = workbook[listaMeses[mes]]

        
        ja_existe = False
        novo_log = [usuario, setor, dados['hostname'], dados['ip'], dados['log'], dados['data_hora']]

       # for imp in impressoras:
         #   novo_log.append(imp)
          #  novo_log.append(cont_por_imp[impressoras.index(imp)])

        for fileira in planilha_logs.iter_rows(min_row = 2, min_col = 1):
            if fileira[0].value == usuario:
                ja_existe = True
                for i, valor in enumerate(novo_log, start=1):
                    planilha_logs.cell(row=fileira[0].row, column=i, value=valor)

                break
                


        if ja_existe == False:
            planilha_logs.append(novo_log) 

    workbook.save(caminho_planilha)        
            
    return "Dados atualizados com sucesso."


if __name__ == '__main__':
    serve(app, host = "0.0.0.0", port = 5000)
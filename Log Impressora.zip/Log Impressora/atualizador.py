import requests
import os
import shutil
import zipfile
import subprocess
from hashlib import sha256
from utils import enviarLogErro

ENDERECO_SERVIDOR = "http://192.168.200.66:5000/"
DIRETORIO_PROJETO = os.path.dirname(os.path.abspath(__file__))
DIRETORIO_APP = os.path.join(DIRETORIO_PROJETO, "app")
DIRETORIO_TEMP = os.path.join(DIRETORIO_PROJETO, "temp")


try:
    os.makedirs(DIRETORIO_TEMP, exist_ok=True)

    print("Baixando update.zip...")
    zip_path = os.path.join(DIRETORIO_TEMP, "update.zip")
    hash_servidor = requests.get(ENDERECO_SERVIDOR + "hash").text.strip()

    conteudo = requests.get(ENDERECO_SERVIDOR + "zip_nova_versao").content
    with open(zip_path, "wb") as f:
        f.write(conteudo)

    # Validação SHA-256
    print("Validando integridade...")
    hash_local = sha256(conteudo).hexdigest()

    if hash_local != hash_servidor:
        enviarLogErro("ERRO! Hash diferente!")
        exit()

    print("Hash OK! Extraindo arquivos...")
    extract_dir = os.path.join(DIRETORIO_TEMP, "app")
    if os.path.exists(extract_dir):
        shutil.rmtree(extract_dir)

    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_dir)

    print("Trocando diretórios...")
    backup_dir = DIRETORIO_APP + "_backup"

    # Remove backup antigo
    if os.path.exists(backup_dir):
        shutil.rmtree(backup_dir)

    os.rename(DIRETORIO_APP, backup_dir)
    os.rename(extract_dir, DIRETORIO_APP)

    print("Limpando temporários...")
    shutil.rmtree(backup_dir)
    shutil.rmtree(DIRETORIO_TEMP)

    print("Atualização concluída!")
    subprocess.Popen(["python", os.path.join(DIRETORIO_APP, "main.py")])
except requests.exceptions.RequestException as e:
    print(f"Erro ao atualizar app: {e}")
    enviarLogErro(f"Erro ao atualizar app: {e}")
    exit()
import socket
from datetime import datetime
import requests
import pandas as pd
import os

hostname = socket.gethostname()
ip = socket.gethostbyname(hostname)
dia = int(datetime.now().strftime("%d"))
ano = int(datetime.now().strftime("%Y"))
mes = int(datetime.now().strftime("%m"))
data_hora = datetime.now().strftime("%d/%m/%Y %H:%M")

url = "http://192.168.200.66:5000/atualizar_planilha"  # IP do servidor


def ler_csv(caminho):
    """Tenta ler o CSV; retorna None se não existir ou der erro."""
    if not os.path.exists(caminho):
        return None
    try:
        return pd.read_csv(caminho, encoding='utf-8', sep=',', skiprows=2, header=None)
    except UnicodeDecodeError:
        return pd.read_csv(caminho, encoding='cp1252', sep=',', skiprows=2, header=None)
    except Exception as e:
        print(f"Erro ao ler {caminho}: {e}")
        return None


if dia <= 20:
    # CSV do mês passado
    if mes == 1:
        csv_mp = rf"C:\Program Files (x86)\PaperCut Print Logger\logs\csv\monthly\papercut-print-log-{ano - 1}-12.csv"
    else:
        csv_mp = rf"C:\Program Files (x86)\PaperCut Print Logger\logs\csv\monthly\papercut-print-log-{ano}-{str(mes - 1).zfill(2)}.csv"

    df_mp = ler_csv(csv_mp)
    log_mp = 0
    if df_mp is not None:
        for i in range(len(df_mp)):
            if datetime.strptime(df_mp.iloc[i, 0], "%Y-%m-%d %H:%M:%S") > datetime(ano, mes - 1, 20):
                log_mp += df_mp.iloc[i, 2]

    # CSV do mês atual
    csv_ma = rf"C:\Program Files (x86)\PaperCut Print Logger\logs\csv\monthly\papercut-print-log-{ano}-{str(mes).zfill(2)}.csv"
    df_ma = ler_csv(csv_ma)
    log_ma = 0
    if df_ma is not None:
        for i in range(len(df_ma)):
            if datetime.strptime(df_ma.iloc[i, 0], "%Y-%m-%d %H:%M:%S") <= datetime(ano, mes, 20):
                log_ma += df_ma.iloc[i, 2]

    log = str(log_ma + log_mp)

else:
    # CSV do mês atual
    csv_ma = rf"C:\Program Files (x86)\PaperCut Print Logger\logs\csv\monthly\papercut-print-log-{ano}-{str(mes).zfill(2)}.csv"
    df_ma = ler_csv(csv_ma)
    log_ma = 0
    if df_ma is not None:
        for i in range(len(df_ma)):
            if datetime.strptime(df_ma.iloc[i, 0], "%Y-%m-%d %H:%M:%S") > datetime(ano, mes, 21):
                log_ma += df_ma.iloc[i, 2]

    log = str(log_ma)

dados = {
    "hostname": hostname,
    "ip": ip,
    "log": log,
    "data_hora": data_hora,
}

res = requests.post(url, json=dados)
print("Resposta do servidor:", res.text)

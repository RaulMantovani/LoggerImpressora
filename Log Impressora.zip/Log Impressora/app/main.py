import os
import requests
import subprocess
import sys

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils import enviarLogErro

ENDERECO_SERVIDOR = "http://192.168.200.66:5000/"
DIRETORIO_APP = os.path.dirname(os.path.abspath(__file__))
DIRETORIO_PROJETO = os.path.dirname(DIRETORIO_APP)

def checarVersao():
    versao_local_caminho = os.path.join(DIRETORIO_APP, "versao.txt")
    if os.path.exists(versao_local_caminho):
        with open(versao_local_caminho, "r", encoding="utf-8") as f:
            versao_local = f.read().strip()
    else:
        versao_local = None

    try:
        versao_servidor = requests.get(ENDERECO_SERVIDOR + 'checar_versao').text.strip()
    except requests.exceptions.RequestException as e:
        print(f"Erro ao conectar com o servidor: {e}")
        enviarLogErro(f"Erro ao conectar com o servidor: {e}")
        return False #não atualiza

    print(f"Versão local:  {versao_local}")
    print(f"Versão servidor: {versao_servidor}")

    if (versao_local == versao_servidor):
        precisa_atualizar = False
    else:
        precisa_atualizar = True
        
    return precisa_atualizar

def main():
    precisa_atualizar = checarVersao()

    if (precisa_atualizar):
        subprocess.Popen(["python", os.path.join(DIRETORIO_PROJETO, "atualizador.py")])
        return
    else:
        subprocess.Popen(["python", os.path.join(DIRETORIO_APP, "enviar_log.py")])

if __name__ == "__main__":
    main()
import requests
import socket
import datetime

def enviarLogErro(mensagem):
    ENDERECO_SERVIDOR = "http://192.168.200.66:5000/"

    hostname = socket.gethostname()
    ip = socket.gethostbyname(hostname)
    data_hora = datetime.now().strftime("%d/%m/%Y %H:%M")

    dados = {
        "hostname": hostname,
        "ip": ip,
        "data_hora": data_hora,
        "mensagem": mensagem
    }

    requests.post(ENDERECO_SERVIDOR + "log_erro", json=dados).text.strip()
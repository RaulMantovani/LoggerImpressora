import requests
import os
import subprocess
import socket
import shutil
import zipfile
from datetime import datetime
from hashlib import sha256

ENDERECO_SERVIDOR = "http://192.168.200.66:5000/"
DIRETORIO_ATUAL = os.path.dirname(os.path.abspath(__file__))
DIRETORIO_APP = os.path.join(DIRETORIO_ATUAL, "..", "app")
DIRETORIO_TEMPORARIO = os.path.join(DIRETORIO_ATUAL, "..", "temp")

def enviarLogErro(mensagem):
    hostname = socket.gethostname()
    ip = socket.gethostbyname(hostname)
    data_hora = datetime.now().strftime("%d/%m/%Y %H:%M")

    dados = {
        "hostname": hostname,
        "ip": ip,
        "data_hora": data_hora,
        "mensagem": mensagem
    }

    requests.post(ENDERECO_SERVIDOR + "registrar_log_erro", json=dados).text.strip()


def checarVersao():
    versao_local_caminho = os.path.join(DIRETORIO_APP, "versao.txt")
    if os.path.exists(versao_local_caminho):
        with open(versao_local_caminho, "r", encoding="utf-8") as f:
            versao_local = f.read().strip()
    else:
        versao_local = None

    try:
        versao_servidor = requests.get(ENDERECO_SERVIDOR + 'checar_versao').text.strip()
    except requests.exceptions.RequestException as e:
        print(f"Erro ao conectar com o servidor: {e}")
        enviarLogErro(f"Erro ao conectar com o servidor: {e}")
    exit()

    print(f"Versão local:  {versao_local}")
    print(f"Versão servidor: {versao_servidor}")

    if (versao_local == versao_servidor):
        precisa_atualizar = False
    else:
        precisa_atualizar = True
        
    return precisa_atualizar

def atualizarApp():
    enviar_log_caminho = os.path.join(DIRETORIO_ATUAL, "app\enviar_log.py")

    
    # Baixa arquivos da pasta
    try:
        arquivos = requests.get(ENDERECO_SERVIDOR + 'listar_arquivos').json()

        os.makedirs(DIRETORIO_TEMPORARIO, exist_ok=True)

        print("Baixando update.zip...")
        zip_path = os.path.join(DIRETORIO_TEMPORARIO, "update.zip")
        hash_servidor = requests.get(ENDERECO_SERVIDOR + "hash").text.strip()

        conteudo = requests.get(ENDERECO_SERVIDOR + "update.zip").content
        with open(zip_path, "wb") as f:
            f.write(conteudo)

        # Validação SHA-256
        print("Validando integridade...")
        hash_local = sha256(conteudo).hexdigest()

        if hash_local != hash_servidor:
            print("ERRO! Hash diferente! Atualização abortada.")
            enviarLogErro("ERRO! Hash diferente!")
            exit()

        print("Hash OK! Extraindo arquivos...")
        extract_dir = os.path.join(DIRETORIO_TEMPORARIO, "app")
        if os.path.exists(extract_dir):
            shutil.rmtree(extract_dir)

        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_dir)

        print("Trocando diretórios...")
        backup_dir = DIRETORIO_APP + "_backup"

        # Remove backup antigo
        if os.path.exists(backup_dir):
            shutil.rmtree(backup_dir)

        os.rename(DIRETORIO_APP, backup_dir)
        os.rename(extract_dir, DIRETORIO_APP)

        print("Limpando temporários...")
        shutil.rmtree(backup_dir)
        os.remove(zip_path)

        print("Atualização concluída!")
    except requests.exceptions.RequestException as e:
        print(f"Erro ao atualizar app: {e}")
        enviarLogErro(f"Erro ao atualizar app: {e}")
    exit()

# envia os dados
subprocess.Popen(["python", os.path.join(DIRETORIO_APP, "enviar_log.py")])